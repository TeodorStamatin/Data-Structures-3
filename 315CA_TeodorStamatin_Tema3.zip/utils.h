// Copyright 2023 <Stamatin Teodor>
#ifndef UTILS_H_
#define UTILS_H_

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"

/* useful macro for handling error codes */
#define DIE(assertion, call_description)                                       \
    do {                                                                       \
        if (assertion) {                                                       \
            fprintf(stderr, "(%s, %d): ", __FILE__, __LINE__);                 \
            perror(call_description);                                          \
            exit(errno);                                                       \
        }                                                                      \
    } while (0)

void insert(linked_list_t *list, char *word);

void autocorrect(linked_list_t *list, char *word, int k);

void autocomplete(linked_list_t *list, char *prefix, int criteria);

void remove_word(linked_list_t *list, char *word);

ll_node_t* getLastNode(ll_node_t* node);

ll_node_t* partition(ll_node_t* low, ll_node_t* high, ll_node_t** newLow, ll_node_t** newHigh);

void swap(ll_node_t *a, ll_node_t *b);

void quickSort(ll_node_t* low, ll_node_t* high);

void sortLinkedList(linked_list_t* list);

#endif  // UTILS_H_