#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "utils.h"
#include "linkedlist.h"

#define MAX_LEN 256
#define MAX_COM 16

int main(void)
{
	linked_list_t *list;
	list = ll_create(sizeof(word_data));
	char command[MAX_COM];
	while (1) {
		scanf("%s", command);
		if(strncmp(command, "INSERT", 6) == 0) {
			char word[MAX_LEN];
			scanf("%s", word);
			insert(list, word);
		}
		if(strncmp(command, "LOAD", 4) == 0) {
			char file[MAX_LEN];
			scanf("%s", file);
			FILE *f = fopen(file, "r");
			DIE(f == NULL, "fopen failed");
			char word[MAX_LEN];
			while (fscanf(f, "%s", word) != EOF) {
				insert(list, word);
			}
			fclose(f);
		}
		if(strncmp(command, "AUTOCORRECT", 11) == 0) {
			char word[MAX_LEN];
			int k;
			scanf("%s %d", word, &k);
			autocorrect(list, word, k);
		}
		if(strncmp(command, "AUTOCOMPLETE", 12) == 0) {
			char word[MAX_LEN];
			int k;
			scanf("%s %d", word, &k);
			autocomplete(list, word, k);
		}
		if(strncmp(command, "REMOVE", 6) == 0) {
			char word[MAX_LEN];
			scanf("%s", word);
			remove_word(list, word);
		}
		if(strncmp(command, "EXIT", 4) == 0) {
			ll_free(&list);
			break;
		}
	}
	return 0;
}
