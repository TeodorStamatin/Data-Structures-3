// Copyright 2023 <Stamatin Teodor>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"
#include "linkedlist.h"

#define MAX_LEN 256

void insert(linked_list_t *list, char *word) {
    ll_node_t *curr;
    curr = list->head;
    while (curr != NULL) {
        word_data *data = curr->data;
        if (strcmp(data->word, word) == 0) {
            data->freq++;
            return;
        }
        curr = curr->next;
    }
    //free(curr);
    word_data *new_node;
    new_node = malloc(sizeof(word_data));
    new_node->word = malloc(strlen(word) + 1);
    memcpy(new_node->word, word, strlen(word) + 1);
    new_node->freq = 1;
    ll_add_nth_node(list, list->size, new_node);
    free(new_node);
}

void swap(ll_node_t *a, ll_node_t *b) {

    word_data *temp = a->data;
    a->data = b->data;
    b->data = temp;
    
}

ll_node_t* getLastNode(ll_node_t* node) {
    while (node != NULL && node->next != NULL) {
        node = node->next;
    }
    return node;
}

ll_node_t* partition(ll_node_t* low, ll_node_t* high, ll_node_t** newLow, ll_node_t** newHigh) {
    word_data* pivot = high->data;
    ll_node_t* i = NULL;
    ll_node_t* j = low;

    while (j != high) {
        word_data* data = j->data;
        if (strcmp(data->word, pivot->word) < 0) {
            if (i == NULL)
                i = low;
            else
                i = i->next;

            swap(i, j);
        }
        j = j->next;
    }

    if (i == NULL)
        i = low;
    else
        i = i->next;

    swap(i, high);
    *newLow = low;

    while (i != NULL && i->next != NULL) {
        *newHigh = i;
        i = i->next;
    }

    return i;
}

void quickSort(ll_node_t* low, ll_node_t* high) {
    if (low != NULL && high != NULL && low != high && low != high->next) {
        ll_node_t* newLow = NULL;
        ll_node_t* newHigh = NULL;
        ll_node_t* pivot = partition(low, high, &newLow, &newHigh);

        if (newLow != pivot) {
            ll_node_t* temp = newLow;
            while (temp->next != pivot)
                temp = temp->next;
            temp->next = NULL;

            quickSort(newLow, temp);

            temp = getLastNode(newLow);
            temp->next = pivot;
        }

        quickSort(pivot->next, newHigh);
    }
}

void sortLinkedList(linked_list_t* list) {
    quickSort(list->head, getLastNode(list->head));
}

void autocorrect(linked_list_t *list, char *word, int k) {
    sortLinkedList(list);
    ll_node_t *curr;
    curr = list->head;
    int ok = 0;
    while(curr != NULL) {

        word_data *data = curr->data;
        char *curr_word = data->word;

        int i = 0, j = 0, len1 = strlen(curr_word), len2 = strlen(word);

        if(len1 != len2) {
            curr = curr->next;
            continue;
        }

        while(i < len1 && i < len2) {
            if (curr_word[i] != word[i]) {
                j++;
            }
            i++;
        }
        if(j <= k) {
            printf("%s\n", curr_word);
            ok = 1;
        }
        curr = curr->next;
    }
    if(ok == 0) {
        printf("No words found\n");
    }
}

void autocomplete(linked_list_t *list, char *prefix, int criteria) {
    ll_node_t *curr;
    curr = list->head;
    int len = strlen(prefix);
    char word1[MAX_LEN], word2[MAX_LEN], word3[MAX_LEN];
    word1[0] = '\0';
    word2[0] = '\0';
    word3[0] = '\0';
    int frequency = 0;
    while(curr != NULL) {
        word_data *data = curr->data;
        char *curr_word = data->word;
        if (strncmp(curr_word, prefix, len) == 0) {
            switch (criteria)
            {
            case 0:
                if(word1[0] == '\0') {
                    strcpy(word1, curr_word);
                } else {
                    if(strcmp(word1, curr_word) > 0) {
                        strcpy(word1, curr_word);
                    }
                }
                if(word2[0] == '\0') {
                    strcpy(word2, curr_word);
                } else {
                    if(strlen(curr_word) < strlen(word2)) {
                        strcpy(word2, curr_word);
                    }
                    if(strlen(curr_word) == strlen(word2)) {
                        if(strcmp(word2, curr_word) > 0) {
                            strcpy(word2, curr_word);
                        }
                    }
                }
                if(word3[0] == '\0') {
                    strcpy(word3, curr_word);
                    frequency = data->freq;
                } else {
                    if(data->freq == frequency) {
                        if(strcmp(word3, curr_word) > 0) {
                            strcpy(word3, curr_word);
                        }
                    } else if(data->freq > frequency) {
                        strcpy(word3, curr_word);
                        frequency = data->freq;
                    }
                }
                break;
            case 1:
                if(word1[0] == '\0') {
                    strcpy(word1, curr_word);
                } else {
                    if(strcmp(word1, curr_word) > 0) {
                        strcpy(word1, curr_word);
                    }
                }
                break;
            case 2:
                if(word2[0] == '\0') {
                    strcpy(word2, curr_word);
                } else {
                    if(strlen(curr_word) < strlen(word2)) {
                        strcpy(word2, curr_word);
                    }
                    if(strlen(curr_word) == strlen(word2)) {
                        if(strcmp(word2, curr_word) > 0) {
                            strcpy(word2, curr_word);
                        }
                    }
                }
                break;
            case 3:
                if(word3[0] == '\0') {
                    strcpy(word3, curr_word);
                    frequency = data->freq;
                } else {
                    if(data->freq == frequency) {
                        if(strcmp(word3, curr_word) > 0) {
                            strcpy(word3, curr_word);
                        }
                    } else if(data->freq > frequency) {
                        strcpy(word3, curr_word);
                        frequency = data->freq;
                    }
                }
                break;
            default:
                break;
            }
        }
        curr = curr->next;
    }
    char *word = "No words found";
    if(word1[0] == '\0')
        strcpy(word1, word);
    if(word2[0] == '\0')
        strcpy(word2, word);
    if(word3[0] == '\0')
        strcpy(word3, word);
    switch (criteria)
    {
    case 1:
        printf("%s\n", word1);
        break;
    case 2:
        printf("%s\n", word2);
        break;
    case 3:
        printf("%s\n", word3);
        break;
    case 0:
        printf("%s\n", word1);
        printf("%s\n", word2);
        printf("%s\n", word3);
        break;
    default:
        break;
    }
}

void remove_word(linked_list_t *list, char *word) {
    ll_node_t *curr;
    curr = list->head;
    int n = 0;
    while(curr != NULL) {
        word_data *data = curr->data;
        char *curr_word = data->word;
        if(strcmp(curr_word, word) == 0) {
            ll_node_t *node;
            node = ll_remove_nth_node(list, n);
            word_data *data_2 = node->data;
            free(data_2->word);
            data_2->word = NULL;
            free(node->data);
            node->data = NULL;
            free(node);
            node = NULL;
            return;
        }
        n++;
        curr = curr->next;
    }
}